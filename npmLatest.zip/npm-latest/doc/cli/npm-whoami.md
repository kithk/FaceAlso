npm-whoami(1) -- Display npm username
=====================================

## SYNOPSIS

    npm whoami [--registry <registry>]

## DESCRIPTION

Print the `username` config to standard output.

## SEE ALSO

* npm-config(1)
* npm-config(7)
* npmrc(5)
* npm-adduser(1)
